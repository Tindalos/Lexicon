# Strategy Guide


In this section we'll be exposing, analyzing and nullifying various common strategies used by the Babylonian Kabbalists and its various franchises.  It will be useful to have this section as a repository in which to do so as I encounter or recall them again, making updates to both wr█ting on and reading about them an easy matter.
