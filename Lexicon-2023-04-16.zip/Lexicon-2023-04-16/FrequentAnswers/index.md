# Frequent Answers

- ###  [Why I redact](Redaction.md)

- ### [*'Who are these guys, anyway?'*](TheseGuys.md)

- ### [How symbolism works](Symbolism.md)

- ### [How 'layering' works](Layering.md)

- ### [About the Telepaths and Propheciers](TelepathsPropheciers.md)

- ### [Lexicon syntax](Syntax.md)

- ### [How this was made](HowMade.md)

