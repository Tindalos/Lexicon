# **How this was made**

By the grace of the Creator.

Gleaning the symbolism required dec█des of effort and research on My part.

The wr█teup was done in [Obs█dian](https://obsidian.md), and it was published on [GitHub Pages](https://pages.github.com) via jobindjohn's excellent '[obs█dian-publish-mkd█cs](https://github.com/jobindjohn/obsidian-publish-mkdocs)' scr█pt using the '[Material for MkD█cs](https://squidfunk.github.io/mkdocs-material/)' scr█pt.

This was very easy to make and publish.  If you're into Obs█dian and would like a local version of this Lexicon to see how it was done, you can get the current Lexicon source files [here](https://github.com/Tindalos/Lexicon/archive/refs/heads/main.zip).

Researchers can build their own Lexicons and even work together to compile terms, definitions and to amass listings of media usage of these symbols to 'prove out' the definitions from context.

