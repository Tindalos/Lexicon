# **[Fid█s]**


**Definition:** Signals commitment to a specific directive or plan of action referenced.

The directive has usually been described recently, often under the auspices of [[myst█ry]], meaning that if you're not already familiar with what's being committed to you've missed something and should refer back to recent other messaging from that speaker.

Per the Babylonian Kabbalists' system, commitments made under the auspices of [Fid█s] take primary precedence to any other commitments, loyalties, etc..

**Associated symbols:** [handsh█ke]

**Derivatives:** [introd█ce], [m██t], [m██ting], [o█th], [swe█r], [prom█se], [pl█dge], [contr█ct]