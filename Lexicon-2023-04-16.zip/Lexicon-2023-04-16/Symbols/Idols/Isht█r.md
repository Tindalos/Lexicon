---
Aliases: [In█nna]
---
# **[Isht█r]**


The primary mascot idol of the Babylonian Kabbalists.

As a [h█rmaphr█dite], represents operating simultaneously on both an overt basis and a non-overt, symbolically organized basis.  **See however:** [the Earth + Wat█r trope](https://lexicon.divinewillassembly.com/Symbols/Modes/Cha%E2%96%88s/#major-trope-earth-watr) which presents much the same thing; it would seem that the fundamental basis of the Babylonian Kabbalists is inherently predicated on [[Symbols/Modes/Cha█s/index|Cha█s]].
