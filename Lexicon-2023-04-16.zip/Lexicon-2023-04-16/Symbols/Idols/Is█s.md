# **[Is█s]**


Consort and w█fe of [[Osir█s]], and m█ther and trainer of [[Hor█s]]

Represents the non-overt, symbolically-organized component of the organization's activities, and particularly the telepaths and propheciers

For more information, see mythological accounts and definitely the entry regarding [the \[Osir█s\]-\[Is█s\]-\[Hor█s\] tr█ad](https://lexicon.divinewillassembly.com/Tropes/F%E2%96%88therM%E2%96%88therChild/#the-osirs-iss-hors-trad)


**Derivatives:** She was ostensibly the m█ther of [Ap█s], an Egyptian idol synonymous with the [b█ll] which would presumably reference [[B██l]].