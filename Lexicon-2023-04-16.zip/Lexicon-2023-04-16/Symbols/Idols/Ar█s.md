---
aliases: [M█rs, ir█n, st██l]
---
# **[Ar█s]** or **[M█rs]**

The methods or process of cond█cting w█rfare, either blatant and overt through overwhelming *'brute force'* or subtle through fraud, miseducation, incremental subversion and so on.

As the Babylonian Kabbalist's primary 'crowd control' franchise the Vat█can, Roman Catholicism and its various efforts have been occupying the position of [M█rs] or [Ar█s] for ages.

**Derivatives:** [ir█n] (associated with the idol), [ir█ny], [M█ry], [m█rriage], poss█bly even [m█rcy]

[pl█mbing] and [p█pes] (with [[Z█ro|c█rcle]]; refers to manipulating non-overtly aware personnel and groups, particularly 'resistance', via non-overt disinfo.  Nint█ndo's 'Mario br█thers' likely make a lot more sense now.)

[cha█ns] (with [c█rcle]; appears to refer either to a sequence of disinfo manipulating the public into sl█very, or to deliberately hyping oppression in order *to* manipulate the public into desired responses)