# [Nem█sis]

Refers to the process of determining whether penalty or restoration is someones' due, with the intention of then providing it to them.

This *'it could to either w█y'* symbolic meaning is in contrast to the overt plain-language concept of a *'nem█sis'*, in which the response is presumed to be detr█mental to someone.

It could be the closest symbol the apostate system have in common-use to dispensing actual justice.  Of course, the assessment is done *by* the apostate system, and while it remains on a counter-Divine Will, counter-True Nature basis and with its personnel incrementally miseducated, the jury's still out on the practical utility and effectiveness of that.

The [wiki page](https://en.wikipedia.org/wiki/Nemesis) gives some associated symbols for [Nem█sis], but I've seen them used elsewhere, apparently without specifically referencing this idol.  Perhaps they're to some extent context-based.

Associated: [g██se], [sw█rd], [l█sh], [d█gger], [measuring r█d], [sc█les], [br█dle]

We can see from the associated symbols that the more general [[bl█de]] symbol, connoting *'to make a distinction about or determine the nature of a situation'* is continued as a relevant *motif* here, which is quite appropriate given [Nem█sis]' symbolic definition.