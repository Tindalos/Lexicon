# **[Remph█n](https://en.wikipedia.org/wiki/Remphan)**


Proprietary methods involving various formulas for lev█raging non-overtly organized crowds to sw█ndle finances from the general public via complicated means.  Hypothecated currencies, *'ins█der tr█ding'*, usury, fractional reserve lending and the like.

**See also:** [[Do█bleTr█angle|Do█ble Tr█angle]] for a more thorough description
