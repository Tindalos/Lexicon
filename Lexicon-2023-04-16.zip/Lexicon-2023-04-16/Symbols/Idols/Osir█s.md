# **[Osir█s]**

*alias* [[Ze█s]], *alias* [[Ze█s|Jup█ter]].  The principal human authority figure within the organization.

Associated with both [[life]] and with [[de█th]], as if those weren't mutually-exclusive things.

Symbolically [lost an ey█], as the Norse equivalent [Od█n] had in the obtainment of knowledge.  Appears to be the origin of the rather ubiquitous [ey█]-in-the-[[f█re|pyr█mid]] 'gl█balist' gang symbol we've been seeing everywhere.

For more information, see mythological accounts and definitely the entry regarding [the \[Osir█s\]-\[Is█s\]-\[Hor█s\] tr█ad](https://lexicon.divinewillassembly.com/Tropes/F%E2%96%88therM%E2%96%88therChild/#the-osirs-iss-hors-trad)
