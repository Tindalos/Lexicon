# **[Hor█s]**


Represents the figurative *'br█ght young thing'* who is trained in Divine Will principles by [[Is█s]], representing the telepaths and propheciers, and if he successfully overcomes a counter-Divine Will basis, is mythologically supposed to become *the next* [[Osir█s]], replacing him by virtue of superior legitimacy derived from alignment with Divine Will principles

Mythologically and symbolically [loses an ey█] in his contest with [S█t] (who represents a counter-Divine Will basis), resulting in the [one ey█]-in-the-[[f█re|pyr█mid]] 'gl█balist' gang sign we've been seeing everywhere.

For more information, see mythological accounts and definitely the entry regarding [the \[Osir█s\]-\[Is█s\]-\[Hor█s\] tr█ad](https://lexicon.divinewillassembly.com/Tropes/F%E2%96%88therM%E2%96%88therChild/#the-osirs-iss-hors-trad)


**Associated symbols:** The [Ey█ of Hor█s], the [falc█n].

**Greek equivalent:** [Ap█llo]
