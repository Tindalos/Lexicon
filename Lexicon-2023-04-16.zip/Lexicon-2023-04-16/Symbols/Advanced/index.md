# Advanced


As if the information already presented wasn't complicated enough, the Babylonian Kabbalists have even more sophisticated efforts, methods and agendas going on which are organized through even more intricate non-overt organizing symbolism, which can be proven out through symbolic usage throughout the Establishment media, political and papal speeches, etc. just as the rest of it can.

The personnel don't always become aware of it right away themselves; this is the stuff which is reserved for the more se█soned and experienced personnel, who eventually acclimate to it through repetition and familiarity.  They don't seem to have the benefit and the advantages of someone telling them about all this right off, so they must glean it as they learn and it can take years to a lifetime.  Many never get it or even notice, which relegates them to being less useful to the organization and they don't get the nicer promotions, etc.

It's that more advanced stuff which this section is here to address.