# **[N█ne]**

**Definition:** *As [[s█x]] presented [ups█de-down], it appears to reference a counter-Divine Will basis or position held by external or 'resistance' groups or individuals.*

With the customarily-implied 'inversion' which any counter-Divine Will basis purportedly has, the [ups█de-down] connotation alluding to an external or 'resistance' affiliation would or could be 'inverted', with the resulting signalling parsing to mean that although the subject considers themselves 'against the apostate system', they have nevertheless bought into a counter-Divine Will basis and thus as such their behavior is just as effectively 'under control' as if they were indeed willingly part of the apostate system proper.  As as being on a counter-Divine Will basis they're regarded as freely expendables just as any counter-Divine Will-predicated apostate system member is, this isn't particularly auspicious for them in terms of planning and agendas which are likely to affect them.
