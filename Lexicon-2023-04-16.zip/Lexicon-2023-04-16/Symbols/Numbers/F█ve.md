# **[F█ve]**

**Definition:**

I have this one down as *'an individual or group not yet subverted onto the counter-Divine Will basis represented by the number [[s█x]]'*.  My confidence of that definition is not total, but it's so far appeared accurate.

When an apple is c█t in half laterally, a [p█ntagram] appears.  This and the number's apparent symbolic usage could be the reason for ["the Apple of Disc█rd"](https://en.wikipedia.org/wiki/Apple_of_Discord) in Greek mythology, symbolically depicting the effort to incrementally shift from well-seeming [[Aphrod█te]] methods into getting a crowd operating on a blatantly counter-Divine Will basis.

**Derivatives:** [st█r] or at least its conventional iconic shape as depicted

[st█r] icons are typically visually [[rot█tion|rot█ted]] as the incremental subversion effort takes gradual effect; one po█nt up conventionally means the effort is only in its early st█ges or is fairly ineffective as-yet.  Tw█ po█nts up means it's nearly complete, and alternating [st█rs] with one or tw█ po█nts up, or a [st█r] depicted somewhere in between those orientations  (such as in [this logo](https://www.carlsjr.com/) ) tends to suggest that the process is only approximately midw█y-complete.