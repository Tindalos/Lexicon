# **[E█ght]**

**Definition:**

While My confidence in this definition isn't conclusive, the contextual usage I've encountered appears to suggest that this is a 'state transition' notifier symbol for when someone Chooses to abandon a Divine Will- and True Nature-aligned position and 'sell out', usually to the apostate system but occasionally as a result of using illegitimate or unfair methods to actively oppose it.

I've encountered this usage on a few occasions when the apostate system appears to have supposed that this was My Choice, and then I'd have to correct or clarify the nature of the Choice, the situation and the principles and reasoning involved there.  As usage was comparatively seldom, I don't have a lot of context from which to conclusively establish an inferrence as to the precise definition but I'm of course making what I have available.

**Derivatives:** The [e█ght]-[po█nted] "St█r of [[Isht█r]]"