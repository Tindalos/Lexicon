# **[T█n]**

This is a [[Earth|male]]-and-[[Wat█r|f█male]] symbol, [[obel█sk]] plus [[z█ro]], thus putting it under the auspices of [[Isht█r]] and making it a group-identifier symbol.

The symbolic 'inversion' which is implied by the counter-Divine Will nature of  [[z█ro]] appears to usually 'invert' it from a merely *apparent* position to a *substantive, genuine* affiliation.  That's merely prevalent usage though; in theory it could be applied to instead 'invert' some other component of the message in which it was used.