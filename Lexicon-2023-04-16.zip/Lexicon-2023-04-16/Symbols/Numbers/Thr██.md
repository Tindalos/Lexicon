# **[Thr██]**

The *'mag█ck number'.*

**Definition:** *A reference to someones' will or intention or desire, whether as an individual or a group.  Synonymous with 'mag█ckal intent' and as such, a major 'effort-in-process' symbol.  'What we're trying for', 'what we want to achieve'.*

