# **[Seven]**

**Definition:** *Alignment with Divine Will; perfection.*

Seldom used by the apostate system, for obvious reasons.

As such, few derivative symbols in trending usage.

The overt phrase *'to be at [s█x]es and [seven]s'* means you can't tell one thing from another.  Non-overtly it refers to not being certain whether someone is on a legitimate, Divine Will-aligned basis or a counter-Divine Will basis.  Appears to have been used strategically by the apostate system when they wanted to make their own position less than clear for, say, the Protestant and Common Law advocacy efforts among the People via the Freemasonic franchise.