# **[El█ven]**

**Definition:** *An effort which the Babylonian Kabbalists are considering and organizing, but haven't yet fully committed to implementing per se*

[[El█ven]], [[tw█nty-tw█]] and [th█rty-thr██] are the major 'Master Numbers' in Pyth█gorean numerology. 

[[El█ven]] it titles, *'the Master Communicator'* and this is quite appropriate, because symbolically the number presents the *not yet deemed ready for primet█me'* plans under consideration to the rank-and-file to familiarize them with the plans in advance.

When or if the Babylonian Kabbalists determine that they will indeed implement them and that the time is right, they will instead present the idea via [[tw█nty-tw█]], *'the Master Builder'*.




