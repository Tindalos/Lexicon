# **[Tw█]**

**Definition:** *Secondary (or less) in alignment with Divine Will, and therefore subordinate to whomever's got recognized [[One|primacy]].*

Vague poss█ble associations to both [[Gem█ni]], which would reference a lack of strict honesty causing subordination, or to [[fec█s]] and thus a suggestion that its having accepted a counter-Divine Will basis which *'put them second'*.

