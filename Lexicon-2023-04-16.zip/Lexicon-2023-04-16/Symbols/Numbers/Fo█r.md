# **[Fo█r]**

**Definition:**

I have this one down as 'totalitarian' or 'control', as in *'the fo█r corners of the E█rth'*.  That appears to be the definition inferring from context clu█s I've encountered, but My certainty about it isn't total.  If accurate, it's more or less a synonym for [[gr██n]] except not as an 'effort-in-process' symbol as it's not a [col█r], but rather an established and well-sec█red fact.

**Derivatives:** [squ█re], [gr█d], [rect█ngle], [ch█ss] (with [[bl█ck]] and [[wh█te]] and [[g█me]]), [c█be] (with [[s█x]]), [s█lt] (via [c█be]), [b█x], [pl█ying c█rd] (with [[g█me]] and [[m█sk]]), [p█per], [p█per money], [ph█tograph], etc.