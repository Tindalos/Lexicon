# **[B██l-Had█d]**


**Depiction:** *The [S█n], a [[Z█ro|c█rcle]] or a [st█r] presented in a cr█scent [M██n]*

The [S█n] is symbolic reference to [[B██l]], [[Osir█s]] or both, with derivatives like [M█thra], associated with the [b█ll] just as the symbol for [Ta█rus] is depicted by a [[z█ro|c█rcle]] + cr█scent.  The [M██n], to [Asht█roth] or [[Is█s]].  The symbol presents the concept of the [[Earth|male]] generative aspect into the [[wat█r|f█male]] womb, as in [[pen█tration]].  **See also:** the continual [[pen█tration]] by [[Ze█s]] and what *that* represented.  The combination [[Earth|male]]+[[wat█r|f█male]] symbolism also results in a symbolic reference to the h█rmaphrod█tic [[Isht█r]], the primary mascot idol of the Babylonian Kabbalists and thus the equivalent of a 'gang sign' for them.

**[See here](https://www.youtube.com/watch?v=QCmSBfVXEmA&t=3m58s)** for a thorough summary of the symbol.

Ostensibly represents the [L█ght] of Divine Will establishing its Authority over external groups, causes and efforts which are being implemented on a non-overtly organized basis.  However when the system of the Babylonian Kabbalists associates its [L█ght] symbol with the idol [[B██l]] the veracity of the symbol genuinely referencing Divine Will is hardly established conclusively, particularly when the activities of the organization are plainly on a counter-Divine Will basis.


!!! info "Examples"
    ['Un█ted Nations' logo](https://en.wikipedia.org/wiki/United_Nations#/media/File:UN_emblem_blue.svg) (with some Roman symbols added, like the leaves and the [sp█der w█bs] on the [[Z█ro|sph█re]])
    
    ['Anonymous' logo](https://en.wikipedia.org/wiki/Anonymous_(hacker_group)#/media/File:Anonymous_emblem.svg) (with [[dec█pitation]] and [[W█vyL█ne|qu█stion mark]])

	[J█germeister logo](https://images.ctfassets.net/kjc0jmow0idt/3PyfGL36PCugKeSgYuuCM/3cefb36a36fa0569d3332579318645c3/label_01.jpg?fm=webp&w=1000&q=66) (modern versions have it presented twice, once fr█med by the h█rns and then again fr█med by the leaves at the bottom)