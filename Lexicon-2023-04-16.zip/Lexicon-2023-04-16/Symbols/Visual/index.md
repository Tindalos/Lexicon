# Visual


Visual symbols, hand gestures and other non-spoken *'convenient shorth█nd'* methods of symbol presentation
