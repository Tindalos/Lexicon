# **[Jagged L█ne]**


A visual reference to the [[Ze█s|l█ghting]] of [[Ze█s]] or [[Ze█s|Jup█ter]] and means the same.

Can occasionally also reference [Th█r] particularly among the Knights of Malta franchise, but that's 'lower layer' and comparatively unimportant for our purposes.

Derivatives: [cr█cks]