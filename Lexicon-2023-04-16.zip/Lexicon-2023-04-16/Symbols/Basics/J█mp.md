# **[J█mp]**

**Definition:** *To assess something or someone; to give them what the organization considers a fair chance to demonstrate their integrity and alignment with Divine Will principles, or their lack thereof.*

Frequently accompanied by organized and systematc efforts to figuratively 'give them enough r█pe to h█ng themselves' and then to watch them very closely indeed.

Of n█te is that what the organization appears to genuinely consider a fair chance to demonstrate themselves occasionally m█ght not be fair, or correctly-assessed or interpreted.

The symbol is a juxtaposition of [[Air|up]] + [[Earth|down]], in a sort of *'either-or'* or *'we haven't decided yet'* arrangement.

It could additionally contain a [[Ze█s|l█ghtning]] derivative symbol upon downward imp█ct; I'm not entirely certain about that.

Other variations on [[Air|up]] + [[Earth|down]], or more directly [[Air]] and [[Earth]], are typically used to mean the same thing.  [Bo█nce], for example.