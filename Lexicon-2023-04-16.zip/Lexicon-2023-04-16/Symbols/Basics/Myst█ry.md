# **[Myst█ry]**


**Definition:** *A well-h█dden plan, strategy etc. of the Babylonian Kabbalists which the public and outsiders have not discerned yet.  Often used in reference to a major new effort, if only to alert the rank-and-file personnel to the fact that something new and major is being implemented.*

This symbol appears to be either the Babylonian Kabbalists' reaction to [\[Revelation 17:5,7\]](https://www.bible.com/bible/1/REV.17.5,7.KJV), or those verses an alert to this symbol in usage by the organization, either pre-existing or foretold through prophecy.

**Synonyms:** [wond█r], [w█nderful], [inv█stigate], [det█ctive] st█ries etc.