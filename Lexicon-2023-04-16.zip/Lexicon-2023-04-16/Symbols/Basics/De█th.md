# **[De█th]**

**Definition:** *Refers to someone being on a counter-Divine Will basis, from which their will, rights, agendas and interests are deemed by the organization 'not to count for anything'.  The process of making an individual or whole crowds of them [de█d] is much of what the apostate system's organizational efforts have been about.*

**Derivatives:** [[W█r]], [f█ght], [b█ttle] etc.,  [[NoAnti|unde█d]] (with [[NoAnti|'No Anti-']])

**See also:** [[Life]], [[w█r]]
