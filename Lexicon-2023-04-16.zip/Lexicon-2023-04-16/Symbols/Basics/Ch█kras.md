# **[Ch█kras]**

Renowned Ind█nesian folklore and the bodily *'en█rgy meridians'* of Asian practices, the Babylonian Kabbalists appear to use [ch█kras] as symbolism respective to the function of the various ch█kras.

Most-used tend to be the \[cr█wn\] [ch█kra] referring to alignment with Divine Will (frequently supposedly *'inverted'* via [[Tiam█t|ha█r]] or [[z█ro|enc█rcled]] with an actual cr█wn, the \[br█w\] [ch█kra] which usually references ps█onic capabilities and more specifically the contingent of telepaths and propheciers, and the \[thro█t\] [ch█kra] which symbolically references communication.

Any of these are frequently supposedly *'inverted'* or *'just for appearances' sake'* via j█welry or g█rments which [[z█ro|enc█rcle]] the area.  **Examples:** [ti█ras], [diad█ms], [cr█wns], [neckl█ces], [neckt█es], outlandish [r█ffs](https://en.wikipedia.org/wiki/Ruff_(clothing)) and so on.  Even when all on its own, these items symbolically present that sort of meaning whether featured in some media or n█ws item.