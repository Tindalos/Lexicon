# **[Dece█t]**

**Definition:** *Used as an ostensible 'inversion' symbol, which as usual purportedly either 'uses up' an 'inversion' in 'inverted mode' or purports to add an additional 'inversion' to the message*

Frequently-used in particular when the Babylonian Kabbalists are presenting as though they were supposed 'resistance' personnel.

**Synonyms:** [tr█ck], [tr█p], [che█t], [l█e] (when not used as such, words like *"untruth"* or *"untrue"* are used instead), [f█lse], [f█ke] (as in for example, [[Examples/index|"f█ke n█ws"]]), [ill█sion], and [[g█me|g█mes]] like [p█ker] (with [[InFr█ntOf|\[in fr█nt of]]\]), [prop█ganda], [hol█gram] (with [l█ght])
