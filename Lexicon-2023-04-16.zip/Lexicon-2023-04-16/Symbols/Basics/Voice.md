# **[Voice]**

**Definition:** *To temporarily promote a specific po█nt of view, usually a disproportionate public representation of an ideology or agenda which could be fair and reasonable, or could be unfair and unreasonable.  Said promotion is done only for strategic purposes and only done for so long as it continues to serve those; the organization has no special 'buy-in' to the various causes or ideologies being promoted*

A rather obvious application of the [[Air]] symbol.

Once the strategic purpose has been served the support van█shes without a tr█ce, leaving next to no evidence it was ever there except perhaps a f██tn█te in the history b██ks.

In getting various marginalized demographics on-side, not to mention controlling their dir█ctions and their agenda, this strategy is quite effective indeed.  All it requires is for the organization to accept a foundation of hypocrisy, attempting to be *'everything to everyone'* as is its stand█rd operating procedure.
