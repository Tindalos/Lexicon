# **[W█r]**

**Definition:** *A supposed confl█ct presented for public appearances, in which all involved 'sides' are in fact controlled by the Babylonian Kabbalists or their various franchises.  The objective isn't to 'win' the item in dispute for either 'side', it's to use the contention to gain external buy-in for one or the other of the 'sides' and, ultimately, to put the onlookers and those affected onto a counter-Divine Will basis as they will typically jettison principle and integrity in order to 'win' the supposed 'cont█st'.  It's effectively an exploitation of the flaw of hypocrisy found in the reasoning that, 'The ends justify the means'

**Synonyms:** [b█ttle], [f█ght], [█lly] (because one having '█llies' presupposes the context of a [w█r])