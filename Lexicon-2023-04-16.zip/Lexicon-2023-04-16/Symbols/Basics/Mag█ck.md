# **[Mag█ck]**


**Definition:** *A non-overt 'effort in process' symbol, with so many derivative symbols that I've had to give them [[Symbols/In-Process/index|a whole section of their own]]

**Derivatives:** [lett█rs] (alphabetic), 