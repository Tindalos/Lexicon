# **[Dr█nk]**


**Definition:** *Something of supposed value being proffered non-overtly, either as a recruitment enticement or as some information or disinformation calculated to influence someones' thinking and basis*

This one's fairly easy; it's the [[wat█r|l█quid]] and therefore non-overt equivalent of their [[f██d]] symbol.

[H█t] [[dr█nk|dr█nks]] additionally add in [[f█re]]; hence the Brit█sh fascination with [te█] and the American equivalent with [c█ffee].

[Alc█holic] [[dr█nk|dr█nks]] generally purport to represent misdirection efforts by supposed 'resistance' members, but this is instead merely a non-overt alibi for the Babylonian Kabbalists to deploy the [[dr█nk]] symbol to bring them under control.  The symbolic nomenclature supposedly used by the 'resistance' efforts was of course propagated and very likely designed by the Babylonian Kabbalists.
