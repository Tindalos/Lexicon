# **[D█ll]**


**Definition:** *Announcement of a directive for rank-and-file personnel to attempt to pass themselves off as personnel of a counterfeit version of an existing group, cause or effort*

From either the [v██doo d█ll] or [[Gem█ni]], likely the latter given the organizational derivation.

Notice that such efforts to convincingly pass themselves off as personnel of an existing outside group relies upon successfully preventing those detecting their efforts from being able to make or establish a distinction between adherents of the genuine article, and their counterfeit version.  As such this and most [[Gem█ni|tw█n]]-derived symbols have [[bl█de]] as their sort of *'ancestor antonym'* concept.  Where that requires *making* a distinction, this relies upon *preventing* one from being made.

Strategically useful for placing blame or public vilification against a group or franchise, or for spreading counterfeit versions of its ideologies and policies among its own personnel and to the public at large.  The Babylonian Kabbalists have been doing this with Christianity for example for cent█ries until prevalent practice of it is hardly even recognizable in comparison, and the public vilification effort against it appears to have succeeded phenomenally.

**Synonyms:** [st█tue], any other inanimate figure of human likeness

**Antonym:** [[bl█de]]