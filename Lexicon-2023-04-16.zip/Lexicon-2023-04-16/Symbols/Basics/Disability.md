# **[Disability]**


**Definition:** *Used to symbolically organize a scheme in which personnel intentionally, deliberately and systematically underperf█rm, deliberately below their genuine ability*

Frequently used when deprecating or doing a *'controlled shutdown'* of lesser franchises

Also represents a Choice to reject their own Divinely-conferred True Nature, which is by definition a counter-Divine Will basis

The symbol appears to also neatly imply its own penalty, which doesn't manifestly seem to be applied when it's being implemented per the organizational will of the Babylonian Kabbalists


**Derivatives:** all manner of mental and physical disabilities, [wh██lcha█r], [w█lking c█ne] (with other symbols like [[trav█l]], etc.)

**Media instances:** ["Slow D█nnie"](https://www.youtube.com/watch?v=c7dkaU_qP8k)
