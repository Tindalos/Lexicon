# **[H█nd]**

[[Air]] + [[Gem█ni]]

**Definition:** *'Promote this counterfeit group, cause, effort, franchise or ideology we've established'*



**Synonyms:** gesturing [up high] either in the air or on the body

**Antonym:** [f██t] or gesturing [down low] either near the ground or on the body.  Typically used when they're directing personnel to deprecate a now-outmoded counterfeit deemed no longer necessary

!!! info "Example"
    When the apostate system intend to 'promote' the Knights of Malta franchise for example, they'll frequently select [[Air]]-derived symbols and gestures with which to accompany it, such as "the N█zi salute" (with [[InFr█ntOf|In Fr█nt Of]], naturally).  By contrast when they mean to deprecate it, they'll instead select [down low] associated imagery and symbolism like [b██ts], as in the oft-used media phrase "[b██ts] on the ground"

**Derivatives:**

[tool use], esp. to refer to intermediary franchises such as Freemasonry

[appla█se], particularly to refer to supposed contention between designated 'opposite number' franchises such as between the stereotypical 'organized crime' syndicates and the Knights of Malta for example.  Also used *to establish* such a designation, or merely for short-term direction of entirely made-for-public contentions

