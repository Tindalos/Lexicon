# **[Beli█f]**

**Definition:** *An 'effort-in-process' symbol derived from mag█ckal workings.  As in 'You gotta beli█ve in order to manifest it'.*

Often reapplied in an overt religious context, though it can just as frequently appear in secular contexts.

**Synonyms:** [re█l] (derivative: [re█lity]), [cr█zy], [issu█s] (derived from [cr█zy]), [im█gine] (particularly with the Jesuit franchise, via [Ign█tian *'contemplative prayer'*](https://www.ignatianspirituality.com/ignatian-prayer/the-spiritual-exercises/ignatian-contemplation-imaginative-prayer/))