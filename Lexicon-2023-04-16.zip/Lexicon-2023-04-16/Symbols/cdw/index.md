# Counter-Divine Will symbols

Whatever an apostate system franchise offers whether it's downlow s█x, dr█gs, insider tr█ding and the like, once it has spread its non-overt social n█twork widely enough and recruited successfully enough to establish sufficient influence, it will generally implement the next ph█se of its activities: shifting its more senior personnel onto a counter-Divine Will basis.


### How the process works

It starts at the top of the franchise and works its way down.  As personnel organize with their 'upl█ne', their seniors from whom they get their whatever-it-is for perks, their requests for support are declined until and unless they 'opt into' a counter-Divine Will, counter-True Nature basis and signal as much by learning and using the appropriate terms.  In other words, they 'sell out'.  It appears that sometimes personnel 'sell out' in return for just not getting bl█ckma█led for the various perks they've been receiving, or sometimes they're so far into debt with the franchise that it's their only viable means of fending off severe penalties.


### The predicament

What are the results?  Personnel 'opt into' a basis which non-overtly purports to be just a new 'mode' in which counter-Divine Will symbols are used just like the 'group identifier' symbols with which they're already familiar.  Through more experience they find that these are used more as 'inversion' symbols, because the parent group controlling the franchise implies that its agenda is consistent with Divine Will.  Personnel also find that the 'perks' they've been seeking tend to evap█rate regardless, because the new rules for their counter-Divine Will basis eventually withdraw and preclude the use of those 'perks', and personnel are now required to provide their non-overt and overt services to the franchise 'for free'.  Not quite 'for free' though; personnel are trying to outperf█rm everybody else enough to get noticed and accrue 'merit' (sort of a hypothecated credit system which is specific to the organization) enough to gain promotions and internal adv█ncement.  Promotions among other things mean access to higher 'layers' of organizing symbolism which enable them to recognize dis█sterous situations being contrived for the lower-rung personnel, and to avoid getting caught up in them themselves.  And gaining 'merit' often means being the 'early adopters' of strategies which manufacture those dis█sterious predicaments for the lower-rung personnel, and for the general public as well.  In essence, personnel on a counter-Divine Will basis have 'opted into' a position of ever more labor and concessions in exch█nge for ever more diminishing returns.  The formula is one of increasing submission to the organization until they've made themselves, and contributed to making everyone around them, sl█ves.


### What it actually means

The nature of a counter-Divine Will basis is one in which personnel have demonstrably chucked out all moral basis of reckoning, and all basis on solid principles and truth.  This makes them great for dispensing prop█ganda, applying peer press█re, inciting sociopolitical activism and ideological rhetoric, mass subversion through normalizing of miseducated ideas, principles and ideas about how law and government 'should work', and so on.  Additionally, it dissociates them from a basis of trustworthiness.  The parent organization knows quite well that Divine Will is the fundament of Creation; they not only retain a knowledge of Divine Will principles (despite appearances), they're the ones who've been actively subverting public knowledge of them.  It also means that personnel on a counter-Divine Will basis are deemed 'expendables', 'common m█ck'.  This is particularly true of personnel who are using not only counter-Divine Will indicator symbolism, but rather blatant counter-Divine Will symbols which are easily-recognized by the public as such, like media figures throwing obvious symbols associated with a counter-Divine Will basis or presenting blatantly-offensive lyr█cs, imagery and so on.  Those are participants in the designated 'villain' contingent, presented for narrative purposes and 'set to go down' when the apostate system's next-iteration bogus 'h█roes' present themselves to implement the next ph█se in their agenda of radical and drastic subversion.  This is done because producing the public effect makes their next-iteration shills appear to be 'h█roes', rather than just the latest merchants p█ddling more of the same.


### 'Permanency'

Personnel are also non-overtly w█rned that opting into a counter-Divine Will basis is a permanent, irrevocable, lifetime commitment.  Of course this information is presented to them on a counter-Divine Will basis which itself is inherently non-credible, but the psychological device co█pled with the intimidation fact█r with regard to the capability for forceful reprisals appears to convince many.


### Spreading the problem

Personnel on a counter-Divine Will, counter-True Nature basis are typically preoccupied with gaining 'merit', and one part of how they can accomplish this is through enticing other personnel onto that same basis.  This can be individually through non-overtly co-ordinated methods, or *en masse* when personnel work together and inter-operate to arrange more large-sc█le situations affecting many.

The transition of personnel onto a counter-Divine Will, counter-True Nature basis is what is meant by the 'basic' symbol [[De█th]].

