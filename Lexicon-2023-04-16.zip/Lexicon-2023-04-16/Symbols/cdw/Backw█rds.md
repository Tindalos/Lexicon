# Backw█rds


Derived from the old folklore *trope* of counter-Divine Will creatures presenting their names [[backw█rds]], later reiterated with the modern pseudo-'Christian' hype about the recording industry supposedly including 'Sat█nic messages' which were only detectable upon playing the media content [[backw█rds]].  Other than the overty psychological effect, the hype was of course merely organizing symbolism as they were shifting personnel onto a counter-Divine Will basis.

Occasionally used to imply to 'resistance' personnel organizational or individual efforts to counter the agendas of the Babylonian Kabbalists, but of course includes that counter-Divine Will basis which leaves it untrustworthy.  More accurately, at least using their supposed 'counter-Divine Will symbols as 'inversion' symbols' trope at least, messages that *'you can't stop 'progr█ss', because we don't recognize you as being on a Divine Will-aligned basis'.*


**Derivatives:** [[Pal█ndrome]], [countdown] (used to indicate an organizational plan which is set to *'go into effect'* unless someone the group recognizes as a superior, Divine Will-aligned authority figure presents themselves and thereby *'canc█ls'* it; a counter-Divine Will plan with a delay, set as the default co█rse of action)
