# **[[Pal█ndrome]]**


**Definition:** *A signal that the current message has been designed to present as though representing the interests of a Divine Will-aligned interest when parsed one w█y, and a counter-Divine Will-based interest when parsed another*

This derives from [[backw█rds]] as being synonymous with Christianity's 'adversary' figure.

When something can be read in either direction, it purports to be intelligible to either interest.

This is normally used to suggest that someone is *'serving tw█ masters'*; that is, the Babylonian Kabbalists who rather curiously take it as read that their authority figure represents a Divine Will-aligned basis, and some external agency or interest.

Of course *'serving tw█ masters'* is exactly the fallacy being deployed and presented to the external interest, and the objective is actually to establish that the external interest is quite willing to accept support on a counter-Divine Will basis.  Once that's been established satisfactorily of course, it supposedly frees the Babylonian Kabbalists up from having to take them seriously because they'll have demonstrated that they're on a counter-Divine Will basis.

If one finds themselves in the position of being presented with this kind of strategy, the appropriate response is to reject it and ask all involved why offering disappointing, unworthy and lackluster support to Divine Will-aligned causes like rights, genuine justice and so on appears to be the best the Babylonian Kabbalists have been willing to do per all available evidence, and what the use or legitimacy of an organization is which does that.







