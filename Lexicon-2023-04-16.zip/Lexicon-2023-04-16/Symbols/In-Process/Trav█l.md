# **[Trav█l]**


This one's very Gnostic.  The basic concept seems to be, *'The thing you desire to bring into manifestation is just as re█l, just as valid and legitimate, as anything you currently see manifested around you.  It just isn't there around you, yet.  But it can be, if you invest enough Will and effort into it!  As you do so the situation will incrementally keep ch█nging, gradually, almost unnoticeably, until you arr█ve at your d█stination and your desired result materializes.'*

That of course is an ideology which is an inv█tation for absolute unconstrained egotism and av█rice, and it's converted neatly into an organizing symbol for directing non-overt group efforts... particularly those which are going to require a long time to produce their results.  Political or ideological subversion, for example.

Occasionally the Babylonian Kabbalists will themselves announce to the rank-and-file when they've symbolically *"arr█ved"*; when they've *"re█ched their d█stination"*.  As with the seemingly omnipresent semi-recent trending of the symbolic organizing phrase, *"Let's unp█ck that."*  Unp█cking is of course what you do once you've arr█ved at your d█stination.  I personally tend to substitute the phrase, *"Let Me unp█ck that for you"*, which is what's said by the officials at customs.  H█pe you haven't brought anything against the Law with you!

Manifesting stuff is effectively arbitrary.  We can make our collective situation more or less anything we'd like, within reason.  But some manifestations are more inherently valid than others.  More in accordance with Divine Will, for example.  More in keeping with our True Nature, which is the very thing which makes them desirable to us.  More in alignment with Divinely-conferred rights, which makes them fair and just, effective and sustainable.  The idea that manifestations lacking alignment with our True Natures and Divine Will are somehow just as inherently *'valid'* and *'legitimate'* as those in alignment with them (presumably because it's *'we'* who want them, and we're just so intrinsically gosh-darned worthwhile and important) is a tremendous fallacy.  Symbolically, it determines just *where* the Babylonian Kabbalist personnel (and those whose lives their activities affect) are indeed "arr█ving" at.  A worthwhile utopia, or a dystopia?  *'We did the thing!'* is hardly useful without evaluating in the context of larger principles just *what* it is you've in fact accomplished, and whether it's even valid or worthwhile, let alone its results stable or indeed safe.


**Derivatives:** [progr█ss] (as in 'progr█ssives'), [m█lestone] (with [[obel█sk]])

