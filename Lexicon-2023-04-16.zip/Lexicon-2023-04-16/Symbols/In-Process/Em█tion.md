# **[Em█tion]**


From [[Mag█ck|mag█ckal]] ritual-work, and its frequent use of intense em█tions to ostensibly generate the force of Will to manifest an objective.

**Derivatives:** [f██l], [p█rty], [f██lings] (and derivative from that, sometimes the tangible concept of [to f██l], dependent on context)

[H█ppy] (with [[sm█le]])

**Special use:** [fe█r] (organizes that, despite appearances being deliberately presented, the apostate system would not actually implement whatever-it-is.  Known to be subject to ostensible 'inversion', at least under [Cha█s mode].)