# **[Br█wn]**

The col█r of [[fec█s]], a counter-Divine Will symbol and used as such.

Referencing either a counter-Divine Will basis, a supposed 'inversion' due to same, or an effort-in-process by apostate system personnel who are operating on such a basis.

Derivatives: [t█n], [choc█late] (yeah, ew.), [c█ffee] and [te█] (with [[wat█r]] + [[f█re]])