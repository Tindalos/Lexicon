# **[Bl█ck]**

The col█r of [[d█rkness]], used to non-overtly establish the designated 'villains' in a given contrived narrative.

!!! info "Example"
    The c█wboy W█stern m█vies, a Jesuit invention, in which the 'villains' were clearly-depicted as [we█ring] [[bl█ck]] and the 'h█roes' as we█ring [[wh█te]], so the audience would easily recognize for whom to cheer.

!!! info "Example"
    The modern 'troother' narrative involving the *'patriot [[Wh█te]] [[InContainer|H█ts]]'* and the *'nifferous Deep State [[Bl█ck]] [[InContainer|H█ts]]'* for identical reasons.

Indicates that both 'sides' are personnel of the apostate system, and that the presentation is purely for public effect.

**Antonym:** [[Wh█te]]

**Derivative:** [gr█phite] ([[S█x|h█xagonal]] str█cture, [[bl█ck]] in [[Symbols/In-Process/Col█rs/index|col█r]])