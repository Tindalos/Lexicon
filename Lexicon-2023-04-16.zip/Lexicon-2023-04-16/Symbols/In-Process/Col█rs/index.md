# [Col█rs]

[Col█rs] in general are 'efforts in process' symbols which derive from their use in mag█ckal rituals.