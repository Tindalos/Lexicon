# **[Yell█w]**

The col█r of the S█n, therefore symbolizing [L█ght].

[L█ght] is implied by the apostate system to reference a Divine Will-aligned True State, yet its usage of [L█ght] and [the S█n] is practically always accompanied by counter-Divine Will symbols as with their [B██l] idol, [Mithr█] and so on.

It appears to be what the organization uses when it *wants to present as* being on a Divine Will-aligned basis, yet has still decided not to be.  Or when it wants to reference outside interests which are, yet needs to add a counter-Divine Will identifier in order to keep their own Chosen position clear for each other.  Such as when Roman Catholic 'tradition' shifted, without any Scriptural basis, the observed date of Jesus' Nativity to [Mithr█]'s.

