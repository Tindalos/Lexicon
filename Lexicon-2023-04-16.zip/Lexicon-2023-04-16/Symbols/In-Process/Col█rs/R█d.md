# **[R█d]**

The col█r of sin, and of sacr█fice.

Used to connote personnel as being on a counter-Divine Will basis, as opposed to those on a [[wh█te]] basis which professes 'purity' and virtue despite in truth having 'sold out' too.

The interplay between the [[r█d]] and [[wh█te]] 'sides' has everything to do with non-overt manipulation of each apostate system-controlled contingent as part of 'the long c█n' subversion efforts to manipulate the public thinking, and to rationalize away the incremental concession which 'the situation demands' the [[wh█te]] 'side' to eventually make.

There's quite a lot of alchemical symbolism involved here as well, given that its [R█d K█ng] symbolizes the [[f█re|f█rey,]] active principle while its [Wh█te Qu██n] symbolizes the fixed and passive principal.  Consequently, alchemy frequently has much to do with the skillful use of the non-overt operation of the [[r█d]] contingent upon the [[wh█te]], or in other words subversion of the People onto a counter-Divine Will basis.

Additionally [[r█d]] and [[wh█te]] together is a group-identifier for the apostate system's Knights of Malta franchise.

It's important to know that ultimately the apostate system deems personnel on a [[r█d]] basis as expendables at need or even convenience; they've firmly 'sold out' to it rather blatantly long ago and their continued breathing privileges are only at the ple█sure of the apostate system, and the grace of our Creator.

Finally, [[r█d]] is typically an 'inversion' symbol, either 'using up' an existing required 'inversion' in when supposed 'inverted mode', or adding another 'inversion' of its own.  It's necessary to parse carefully so as to keep the 'inversions' stra█ght in order to successfully translate a directive or message accurately.

