# **[Br█ck]**

Not an element *per se*, but an important symbol for which this is likely the best category to include it.

[[Earth]] + [[f█re]] + [[fo█r|rect█ngle]], this appears to reference a counter-Divine Will basis manifestly accepted by the public.  And as such, the Babylonian temples were comprised of [[br█ck|br█cks]], each un█form and sh█ped to f█t the architectural plan.  The [[br█ck|br█cks]] appear to symbolically represent the People themselves.  Of course they were either [[r█d]] or [[br█wn]], and whichever would still represent a counter-Divine Will basis.

Without the People accepting a counter-Divine Will basis for their lives, the Babylonian Kabbalists cannot re-establish their temples either in their original or in their modern, permuted variants.