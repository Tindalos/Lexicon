# **[[Oobl█ck]]**

Not an element in and of itself, but a combination of [[wat█r]] + [[earth]] symbolism.

Technically refers to both overt and to non-overt basis, or with supposed 'inverted mode' symbolism to mean either one or the other.

More customarily used to reference [[Symbols/Modes/Cha█s/index|'Cha█s mode']] symbolism.

**Derivatives:** [cem█nt] and [concr█te], [porr█dge], [cust█rd] etc. (with [[f██d]])