# Elements

These are the classical 'Greek' elements, but of course the Greek empire and thought had been usurped by the Babylonian Kabbalists as a franchise.

Because these elements are so fundamental in practically everything we use, practically everything we use can be symbolically interpreted as an extrapolation of those and other basic symbols.  Because this means they're so convenient for the apostate system's own subverters and infiltrators to use as organizing symbolism, we need to know how they're using them too.