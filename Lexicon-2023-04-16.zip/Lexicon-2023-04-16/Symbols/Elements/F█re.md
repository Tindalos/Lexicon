# **[F█re]**

**Definition:** *A counter-Divine Will basis or effort, w█rfare (whether implemented overtly or non-overtly), or both*

This symbol and its plethora of derivatives are used perhaps the most frequently by the apostate system, likely due to its manifestly counter-Divine Will basis and agendas, and its willingness to pull 'its' personnel onto a counter-Divine Will basis and to deploy them on it.  Also likely because it has illustrated a tendency to categorize, at least to 'its' rank-and-file personnel, that external groups refusing to submit to or enjoin it are themselves on a counter-Divine Will basis.  This is expedient because it purports to justify its own efforts to stop, marginalize, mitigate and occasionally to extirpate those groups with extreme force or similar non-overt methods.

Also frequently used, sl█ppily it seems, to add a supposed 'inversion' symbol, or to 'use up' an 'inversion' when ostensible 'inverted mode' symbolism is being deployed.

Occasionally used to supposedly 'invert to' referencing the activities of an outsider group or individual.

The apostate system also uses [[f█re]] and indeed all symbols it categorizes as counter-Divine Will symbols as supposed 'inversion' symbols, evidently as part of an implied claim to the rank-and-file that *'**We** certainly wouldn't operate on a counter-Divine Will basis, not us, no!'*  This is an implied claim which finds itself in confl█ct with tho█sands of years of its organizational activities and resultants, both direct and indirect.

Geometrically depicted by an equilateral tr█angle with its bottom l█ne horizontal, **see:** [[Do█bleTr█angle|Do█ble Tr█angle]] in which it is superimposed on the [[wat█r]] tr█angle.  Also of course the dynastic Egyptian pyr█mids and those of so many other cultures.

**Synonyms:** [he█t], [w█rmth] etc., c██ked [[f██d]] and [c██king] in general, [h█t] [[dr█nk|bev█reges]] (with [[Wat█r]]; **see:** [[Tiam█t]])

**Antonyms:** [coldness], [ice] (*very* seldom-used)