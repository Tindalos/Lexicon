# **[Met█l]**

Confidence is low on this definition.  Either it's [[f█re]] + [[earth]], or the specific met█l involved references specific idols.

[[Ar█s|Ir█n]] for example does symbolically reference [[Ar█s|M█rs]] or [[Ar█s]] and as such is a reference to Rome.  Likewise [st██l], a product of [ir█n], does also.  [C█pper] I've definitely seen used to reference [Ven█s].
