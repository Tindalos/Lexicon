# **[Gl█ss]**

**Definition:** *A counter-Divine Will-based effort to dist█rt someones' perception of a situation, just as literal gl█ss dist█rts the l█ght.*

Could also have implications of the use of [[f█re]] to 'undo' the effects of [[D█st|s█nd]].

!!! info "Example"
    The elaborate, ostentatious and be█utifully-[col█red] sta█ned-[[gl█ss]] [[gl█ss|wind█ws]] deployed in Roman Catholicism.

**Major deployments:** Micros█ft Wind█ws (with Bill G█tes' activities hyped for use as 'limited exposure' distractions and misdirections for the 'troothers' due to his public association with the symbol), the more ordinary variety of [wind█ws], eyewe█r (with [[m█sk]]), [fib█r opt█cs] (with [[Tiam█t]]), anything emphasized as having [[gl█ss]] as its major component.