# **[Espi█nage]**

**Likely derivative of:** [[Dece█t]]

When lower-franchise personnel 'graduate' to 'higher level' parent group\[s\], they usually still deploy the 'lower layer' symbolism of their previous franchise alignment for reasons of practicality.  Logistics requires that the pret█nse of those franchises must be maintained, so that the personnel still yet to graduate from them can be sufficiently manipulated and maneuvered without everybody 'getting wise' to the parent group all at once.  And when these personnel 'graduate' up, they tend to keep using *'inversion mode'* with the parent group\[s\] if they had been with their entry-level franchises.  I'm not sure why.

But it's for this reason that I've been unable to confirm whether this symbol, as an apparent derivative of [[dece█t]], is actually a supposed *'inversion mode'* indicator at the Babylonian Kabbalist *'layer'* or merely at the lower franchise layer, most often used by Knights of Malta personnel who are using *'inversion'* down at that level.  Worth noticing regardless, and in need of f█rther evaluation.