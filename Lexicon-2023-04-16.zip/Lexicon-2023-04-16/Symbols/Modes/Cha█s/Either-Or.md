# Either-Or


This is a symbolic *trope* used by the Babylonian Kabbalists to designate *'[cha█s] mode'*

Given the occ█ltist basis of ideology on which is predicated, *'I manifest as I speak'*, and in which non-overt symbolism of [s█lence] and [[mag█ck]] are used to imply the will and intention of the speaker, what is to be made when they present tw█ or more mutually-exclusive poss█bilities or alternatives together with each other?

That they are not using the standard non-overt *'mode'* referenced by [sil█nce]

That their non-overt implications are not to be interpreted as seriously-intended, or are demarcated by some other, usually more privately-held and proprietary, symbolic means
