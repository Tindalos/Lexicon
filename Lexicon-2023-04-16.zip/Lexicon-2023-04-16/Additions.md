# Additions


###### **Notice:** The Lexicon is experiencing technical hicc█ps due to various components for the compile process upgrading and being deprecated pretty much at whim and with spontaneous gl██ful abandon.  L█nks in particular are not being parsed correctly and directing to where they should.


Added since publication:

Additional content to **[[Sc█llaCharybd█s|Sc█lla and Charybd█s]]** entry

**[[Franchises/index|Franchises]]** section, with **[[CopsR█bbers|Cops and R█bbers]]** entry

Symbols, Advanced: **[[Symbols/Advanced/Contingencies/index|Contingencies]]** section, pending **Media** evidence additions

Strategy: **[[ControlledShutdown|Controlled Shutdown]]**

**[[Trends/index|Trends]]** section

**[[StrategyGuide/index|Strategy Guide]]** section

**[[Disability|Disabil█ty]]** symbol