# Franchises

This section will provide summary briefs on many of the major franchises involved

The majority of them are franchises of Rome under Babylon