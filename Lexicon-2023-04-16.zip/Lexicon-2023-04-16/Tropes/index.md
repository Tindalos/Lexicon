# Tropes

This section is devoted towards clarifying various recurring, standard-use non-overt conventions and syntax used by the Babylonian Kabbalists, to provide for easier and greatly-improved readability of their messaging for novices.

They're not exactly symbols *per se*, but rather are recurring patterns and formats of usage which those parsing symbolic content would need to know.