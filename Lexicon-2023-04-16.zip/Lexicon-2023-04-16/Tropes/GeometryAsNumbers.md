# **Geometric shapes as numbers**

Numerological symbols can be, and frequently are, represented visually, using a basic common-sense 'count the sides' method.

With numbers like [[z█ro]] this can even be done in thr██ dimensions, which makes a sph█re and means the same thing as [[z█ro]] does, namely 'purely for public effect' or 'substance-free', unless it's being 'inverted'.
