---
og_image: /img/avatar.png
---

# Summary


Exposing the organizing symbolism used by 'the gl█balists'

Specifically, the *'parent group'* of Babylonian Kabbalists which control practically all the rest as franchises

The parent group's symbolism is in use by all the rest of them, with their own subset *'layered on'* in addition

The organizing symbolism of those franchises can be addressed later in other Lexicons, but the parent group's is the most important and thus the most urgent priority

![](/img/ApostateOrgChart.png)