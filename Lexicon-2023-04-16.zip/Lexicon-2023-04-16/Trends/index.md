# Trends


This section is devoted to c█tching and exposing specifically current trends being implemented, or even still just non-overtly organized, by the apostate system.